import React from 'react'
import HomeComponent from '../components/Home/Home'

const Home = () => {
  return (
    <div><HomeComponent/></div>
  )
}

export default Home