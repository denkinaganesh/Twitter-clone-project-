import React from "react";
import AppRouter from "./components/Router";

const App = () => {
  return <AppRouter />;
};

export default App;
